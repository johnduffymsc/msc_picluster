/* This file is auto generated, version 13+jf */
/* SMP */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#13+jf SMP Wed Jul 8 19:08:30 UTC 2020"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "node9"
#define LINUX_COMPILER "gcc version 9.3.0 (Ubuntu 9.3.0-10ubuntu2)"
