#define LINUX_VERSION_CODE 328748
#define KERNEL_VERSION(a,b,c) (((a) << 16) + ((b) << 8) + (c))
